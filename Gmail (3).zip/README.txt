DL DECORACIONES LIBRA - PÁGINA WEB

1. El archivo principal es index.html.
2. Ábrelo en un navegador para probarlo.
3. Para publicarlo gratis, súbelo a GitHub y activa GitHub Pages.
4. Las fotografías incluidas son imágenes de ejemplo. Después puedes sustituirlas por tus fotos reales.
5. El formulario de cotización abre WhatsApp y no necesita servidor.

Datos incluidos:
- DL Decoraciones Libra
- Tú Casa · Tú Moda · Tú Estilo
- Desde 1987
- WhatsApp/teléfono: 55 39 50 25 41
- Correo: dldecoraciones16@gmail.com
- Ubicación: Río Venezuela, Colinas del Lago, Cuautitlán Izcalli, Estado de México
